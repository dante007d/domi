/**
 * Katana Inspired Platformer Game Logic
 */

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Game Constants
const CANVAS_WIDTH = 1280;
const CANVAS_HEIGHT = 720;
const GRAVITY = 0.5;
const JUMP_STRENGTH = -12;
const PLATFORM_COLOR = '#8b4513'; // Brown
const PLAYER_SIZE = 30;

// Set up canvas dimensions
canvas.width = CANVAS_WIDTH;
canvas.height = CANVAS_HEIGHT;

// Game state management
let gameState = {
    currentLevel: 1,
    isRunning: false,
    player: null,
    platforms: [],
    keys: {
        left: false,
        right: false,
        jump: false,
        dash: false
    }
};

class Player {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = PLAYER_SIZE;
        this.height = PLAYER_SIZE;
        this.vx = 0;
        this.vy = 0;
        this.isGrounded = false;
        this.isJumping = false;
        this.maxHealth = 3;
        this.health = 3;
        this.dashCooldown = 0;
        this.dashDuration = 150; // ms
    }

    update() {
        // 1. Apply Gravity
        this.vy += GRAVITY;

        // 2. Handle Horizontal Movement
        this.vx = 0;
        if (gameState.keys.left) {
            this.vx = -8;
        } else if (gameState.keys.right) {
            this.vx = 8;
        }

        // 3. Handle Jumping and Dash Input
        if (gameState.keys.jump && this.isGrounded && !this.isJumping) {
            this.vy = JUMP_STRENGTH;
            this.isJumping = true;
            this.isGrounded = false;
        }

        if (gameState.keys.dash && this.dashCooldown <= 0) {
            this.dash();
        }

        this.dashCooldown = Math.max(0, this.dashCooldown - 1);

        // 4. Update Position
        this.x += this.vx;
        this.y += this.vy;

        // 5. Collision Detection: Check for platforms (Grounding)
        let hitPlatform = false;
        let newY = this.y;
        let newX = this.x;

        for (const platform of platforms) {
            if (this.x < platform.x + platform.width &&
                this.x + this.width > platform.x &&
                this.y + this.height > platform.y &&
                this.y < platform.y + platform.height) {

                // Simplified check: assume vertical collision is what we care about for grounding
                // If the bottom of the player is within a small tolerance (2px) of the top of the platform
                if (Math.abs(this.y + this.height - platform.y) < 2 && Math.abs(this.vx) > 0) {
                    // Collision detected from above, ground the player
                    newY = platform.y - this.height;
                    hitPlatform = true;
                }
            }
        }
        this.y = newY;
        this.isGrounded = hitPlatform;

        // 6. Boundary checking
        if (this.x < 0 || this.x + this.width > CANVAS_WIDTH) {
            this.x = Math.max(0, Math.min(this.x, CANVAS_WIDTH - this.width));
            this.vx = 0;
        }
    }

    dash() {
        // Implement dash logic (needs state tracking and collision handling)
        this.vx = (gameState.keys.right ? 1 : -1) * 15; // Dash speed
        this.vy = 0;
        this.isJumping = false;
        this.dashCooldown = 2000; // Cooldown in ms
        // Duration check in the update loop will handle the actual timing
    }

    // Dummy collision checker placeholder
    checkCollisions(platforms) {
        // In a real game, this would check for overlap with platforms and return true if grounded.
        return false;
    }

    draw() {
        ctx.fillStyle = 'blue';
        ctx.fillRect(this.x, this.y, this.width, this.height);
    }
}

// Initialize Player
gameState.player = new Player(100, CANVAS_HEIGHT - 100 - PLAYER_SIZE);

class Enemy {
    constructor(x, y, patrolRange, speed) {
        this.x = x;
        this.y = y;
        this.width = 30;
        this.height = 30;
        this.vx = speed;
        this.vy = 0;
        this.patrolRange = patrolRange;
        this.speed = speed;
        this.health = 2;
    }

    update() {
        // 1. Apply Gravity
        this.vy += GRAVITY;

        // 2. Patrol movement
        if (this.x + this.width < this.patrolRange * -1 || this.x > this.patrolRange * 1 + CANVAS_WIDTH) {
            this.vx = -this.vx; // Reverse direction
        }

        // 3. Update Position
        this.x += this.vx;
        this.y += this.vy;

        // 4. Collision Detection (Simplified)
        // Needs dedicated platform collision logic like the player
    }

    takeDamage() {
        this.health -= 1;
        console.log("Enemy damaged. Health remaining:", this.health);
        if (this.health <= 0) {
            // Enemy defeated: award points and remove
            gameState.score += 100;
            // Remove enemy from gameState.enemies array
        }
    }

    draw() {
        // Draw enemy sprite
        drawRect(this.x, this.y, this.width, this.height, SPRITE_COLORS.enemy);
    }
}

// Input handling
document.addEventListener('keydown', (e) => {
    if (!gameState.isRunning) return;
    let key = '';
    switch (e.key) {
        case 'ArrowLeft':
        case 'a':
            gameState.keys.left = true;
            break;
        case 'ArrowRight':
        case 'd':
            gameState.keys.right = true;
            break;
        case ' ': // Space bar for jump
        case 'w':
        case 'ArrowUp':
            gameState.keys.jump = true;
            break;
        case 'Shift':
            gameState.keys.dash = true;
            break;
        default:
            break;
    }
});

document.addEventListener('keyup', (e) => {
    let key = '';
    switch (e.key) {
        case 'ArrowLeft':
        case 'a':
            gameState.keys.left = false;
            break;
        case 'ArrowRight':
        case 'd':
            gameState.keys.right = false;
            break;
        case ' ':
        case 'w':
        case 'ArrowUp':
            gameState.keys.jump = false;
            break;
        case 'Shift':
            gameState.keys.dash = false;
            break;
        default:
            break;
    }
});

// Game Loop
function gameLoop() {
    if (!gameState.isRunning) return;

    // Clear canvas
    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Update game state
    gameState.player.update();

// Game Loop
function gameLoop() {
    if (!gameState.isRunning) return;

    // Clear canvas
    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // 1. Draw the background/level environment
    drawLevelEnvironment();

    // 2. Update game state
    gameState.player.update();

    // 3. Draw game elements
    drawPlayer();
    drawPlatforms();
    drawHazards();
    drawParticles();

    // Loop
    requestAnimationFrame(gameLoop);
}

// Drawing functions
function drawLevelEnvironment() {
    // Draw background elements if needed
}

function drawPlayer() {
    // Draw sprite for the player
    drawRect(gameState.player.x, gameState.player.y, gameState.player.width, gameState.player.height, SPRITE_COLORS.player);
}

function drawPlatforms() {
    for (const platform of gameState.platforms) {
        // Draw platform sprite
        drawRect(platform.x, platform.y, platform.width, platform.height, SPRITE_COLORS.platform);
    }
}

function drawHazards() {
    for (const hazard of gameState.hazards) {
        let color = '';
        switch(hazard.type) {
            case 'spike':
                color = SPRITE_COLORS.hazard_spike;
                break;
            case 'lava':
                color = SPRITE_COLORS.hazard_lava;
                break;
            case 'laser':
                color = SPRITE_COLORS.hazard_laser;
                break;
            default:
                color = '#f00';
        }
        // Draw hazard sprite
        drawRect(hazard.x, hazard.y, hazard.width, hazard.height, color);
    }
}

function drawParticles() {
    // Placeholder for particle drawing logic
}

function updateScore(points) {
    gameState.score += points;
    console.log("Score:", gameState.score);
}
// Start the game when the script loads
startGame();
