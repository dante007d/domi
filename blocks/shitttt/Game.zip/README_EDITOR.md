# PROFESSIONAL 2D LEVEL EDITOR v2

A high-performance, professional-grade level editor for 2D games.

## 🚀 Quick Start

1. Include the CSS:
   ```html
   <link rel="stylesheet" href="editor/editor.css">
   ```
2. Initialize in your game script:
   ```javascript
   import { initEditor } from './editor/index.js';
   initEditor(window.gameState);
   ```
3. Press **\` (backtick)** to toggle the editor at any time.

## 🛠 Features

- **Full Toolset**: Select, Draw, Erase, Entity Placer, Collision Painter, and more.
- **Layer System**: Photoshop-style layer stack with parallax and opacity controls.
- **Entity Inspector**: Edit any entity property live.
- **Visual Scripting**: Node-based logic editor for events and actions.
- **Undo/Redo**: 200+ step command-based history.
- **Asset Manager**: IndexedDB-backed management for tilesets, sprites, and audio.

## ⌨️ Shortcuts

| Key | Action |
|-----|--------|
| ` | Toggle Editor |
| V | Select Tool |
| D | Draw Tool |
| E | Erase Tool |
| Ctrl + S | Save Level |
| Ctrl + Z | Undo |
| Space + Drag | Pan Camera |

## 📁 Level JSON Schema

The editor exports to a standard `.level.json` format containing all tiles, entities, and world settings.

---
*Built with ❤️ for Game Developers*
