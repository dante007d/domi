/* editor/DialogueEditor.js */
export class DialogueEditor {
    constructor(editor) {
        this.editor = editor;
        this.isOpen = false;
        this.createModal();
    }

    createModal() {
        this.modal = document.createElement('div');
        this.modal.id = 'dialogue-editor-modal';
        this.modal.className = 'editor-modal';
        this.modal.innerHTML = `
            <div class="modal-header">
                <span>DIALOGUE TREE EDITOR</span>
                <button class="modal-close">×</button>
            </div>
            <div class="modal-body">
                <div class="dialogue-canvas-container">
                    <canvas id="dialogue-canvas"></canvas>
                </div>
                <div class="dialogue-palette">
                    <div class="palette-title">DIALOGUE NODES</div>
                    <div class="node-type" data-type="speaker">Speaker Node</div>
                    <div class="node-type" data-type="text">Text Node</div>
                    <div class="node-type" data-type="choice">Choice Node</div>
                </div>
            </div>
        `;
        document.body.appendChild(this.modal);
        
        this.modal.querySelector('.modal-close').onclick = () => this.close();
    }

    open() {
        this.modal.style.display = 'flex';
        this.isOpen = true;
    }

    close() {
        this.modal.style.display = 'none';
        this.isOpen = false;
    }
}
