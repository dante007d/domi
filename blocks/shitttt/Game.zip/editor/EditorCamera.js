/* editor/EditorCamera.js */
export class EditorCamera {
  constructor() {
    this.x = 0;
    this.y = 0;
    this.zoom = 1;
    this.isPanning = false;
    this.lastMouseX = 0;
    this.lastMouseY = 0;
  }

  screenToWorld(sx, sy, canvas) {
    const rect = canvas.getBoundingClientRect();
    return {
      x: (sx - rect.left - this.x) / this.zoom,
      y: (sy - rect.top - this.y) / this.zoom
    };
  }

  worldToScreen(wx, wy) {
    return {
      x: wx * this.zoom + this.x,
      y: wy * this.zoom + this.y
    };
  }

  pan(dx, dy) {
    this.x += dx;
    this.y += dy;
  }

  setZoom(newZoom, centerX, centerY) {
    const worldPos = this.screenToWorld(centerX, centerY, { getBoundingClientRect: () => ({ left: 0, top: 0 }) });
    this.zoom = Math.max(0.1, Math.min(8, newZoom));
    // Re-adjust x/y to keep centerX/Y focused (simplified)
  }
}
