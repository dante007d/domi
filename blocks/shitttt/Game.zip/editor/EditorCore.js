/* editor/EditorCore.js */
import { EditorCamera } from './EditorCamera.js';
import { EditorRenderer } from './EditorRenderer.js';
import { ToolManager } from './ToolManager.js';
import { LayerManager } from './LayerManager.js';
import { UndoManager } from './UndoManager.js';
import { PropertiesPanel } from './PropertiesPanel.js';
import { TilesetManager } from './TilesetManager.js';
import { SaveSystem } from './SaveSystem.js';
import { VisualScriptEditor } from './VisualScriptEditor.js';
import { DialogueEditor } from './DialogueEditor.js';

export class EditorCore {
  constructor(shell, adapter) {
    this.shell = shell;
    this.adapter = adapter;
    this.active = false;
    
    this.camera = new EditorCamera();
    this.renderer = new EditorRenderer(this, document.getElementById('editor-canvas'));
    this.toolManager = new ToolManager(this);
    this.layers = new LayerManager(this);
    this.undoManager = new UndoManager(this);
    this.props = new PropertiesPanel(this);
    this.tiles = new TilesetManager(this);
    this.saveSystem = new SaveSystem(this);
    this.scripts = new VisualScriptEditor(this);
    this.dialogue = new DialogueEditor(this);
    
    this.setupEventListeners();
    this.loop();
  }

  setupEventListeners() {
    window.addEventListener('keydown', (e) => {
      if (e.key === '`') {
        this.toggle();
      }
      
      // Global hotkeys
      if (this.active) {
          if (e.ctrlKey && e.key === 'z') this.undoManager.undo();
          if (e.ctrlKey && e.key === 'y') this.undoManager.redo();
          if (e.ctrlKey && e.key === 's') {
              e.preventDefault();
              this.saveSystem.saveToFile();
          }
          if (e.key === 'n' && !e.ctrlKey) this.scripts.open();
          if (e.key === 't' && !e.ctrlKey) this.dialogue.open();
      }
    });

    const canvas = document.getElementById('editor-canvas');
    canvas.addEventListener('mousedown', (e) => this.toolManager.handleMouseDown(e));
    canvas.addEventListener('mousemove', (e) => this.toolManager.handleMouseMove(e));
    canvas.addEventListener('mouseup', (e) => this.toolManager.handleMouseUp(e));
    
    window.addEventListener('resize', () => this.handleResize());
  }

  handleResize() {
    const editorCanvas = document.getElementById('editor-canvas');
    if (editorCanvas && this.active) {
      const rect = editorCanvas.parentElement.getBoundingClientRect();
      editorCanvas.width = rect.width;
      editorCanvas.height = rect.height;
    }
  }

  loop() {
    if (this.active) {
      this.renderer.render();
    }
    requestAnimationFrame(() => this.loop());
  }


  toggle() {
    this.active = !this.active;
    const editorCanvas = document.getElementById('editor-canvas');
    if (this.active) {
      this.adapter.pause();
      this.shell.show();
      editorCanvas.style.pointerEvents = 'all';
      // Sync canvas size
      const rect = editorCanvas.parentElement.getBoundingClientRect();
      editorCanvas.width = rect.width;
      editorCanvas.height = rect.height;
    } else {
      this.adapter.resume();
      this.shell.hide();
      editorCanvas.style.pointerEvents = 'none';
    }
  }

  setTool(toolId) {
    this.toolManager.setTool(toolId);
    this.shell.updateToolUI(toolId);
  }
}
