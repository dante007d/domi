/* editor/EditorRenderer.js */
export class EditorRenderer {
  constructor(editor, canvas) {
    this.editor = editor;
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.gridSize = 32;
  }

  render() {
    const { ctx, canvas } = this;
    const { camera } = this.editor;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    ctx.save();
    ctx.translate(camera.x, camera.y);
    ctx.scale(camera.zoom, camera.zoom);

    this.drawGrid();
    this.drawOverlays();

    ctx.restore();
  }

  drawGrid() {
    const { ctx, editor } = this;
    const { width, height } = editor.adapter.getWorldDimensions();
    
    ctx.strokeStyle = 'rgba(255,255,255,0.05)';
    ctx.lineWidth = 1 / editor.camera.zoom;
    
    ctx.beginPath();
    for (let x = 0; x <= width; x += this.gridSize) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
    }
    for (let y = 0; y <= height; y += this.gridSize) {
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
    }
    ctx.stroke();
  }

  drawOverlays() {
    // Draw selection boxes, etc.
  }
}
