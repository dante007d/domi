/* editor/LayerManager.js */
export class LayerManager {
    constructor(editor) {
        this.editor = editor;
        this.layers = [
            { id: 'bg', name: 'Background', type: 'BACKGROUND', visible: true, locked: false, opacity: 1, parallaxX: 0.5, parallaxY: 0.5 },
            { id: 'main', name: 'Main Layer', type: 'TILE_LAYER', visible: true, locked: false, opacity: 1, parallaxX: 1, parallaxY: 1 },
            { id: 'fg', name: 'Foreground', type: 'FOREGROUND', visible: true, locked: false, opacity: 1, parallaxX: 1.2, parallaxY: 1.2 }
        ];
        this.activeLayerIndex = 1; // Default to main
    }

    get activeLayer() {
        return this.layers[this.activeLayerIndex];
    }

    setActiveLayer(index) {
        if (index >= 0 && index < this.layers.length) {
            this.activeLayerIndex = index;
            this.editor.shell.updateLayersUI(this.layers, this.activeLayerIndex);
        }
    }

    toggleVisibility(index) {
        this.layers[index].visible = !this.layers[index].visible;
        this.editor.shell.updateLayersUI(this.layers, this.activeLayerIndex);
    }

    addLayer(name, type) {
        const newLayer = {
            id: 'layer_' + Date.now(),
            name: name || 'New Layer',
            type: type || 'TILE_LAYER',
            visible: true,
            locked: false,
            opacity: 1,
            parallaxX: 1,
            parallaxY: 1
        };
        this.layers.push(newLayer);
        this.editor.shell.updateLayersUI(this.layers, this.activeLayerIndex);
    }
}
