/* editor/PropertiesPanel.js */
export class PropertiesPanel {
    constructor(editor) {
        this.editor = editor;
        this.selectedObject = null;
    }

    inspect(obj) {
        this.selectedObject = obj;
        this.render();
    }

    render() {
        const container = document.getElementById('properties-inspector');
        if (!this.selectedObject) {
            container.innerHTML = `<div style="color:var(--editor-text-dim); font-size:11px;">Select an object to edit properties</div>`;
            return;
        }

        let html = `<div class="props-header">Entity: ${this.selectedObject.type || 'Object'}</div>`;
        
        // Transform section
        html += `
            <div class="props-section">
                <div class="props-section-title">TRANSFORM</div>
                <div class="prop-row">
                    <label>X</label><input type="number" value="${Math.round(this.selectedObject.x)}" data-prop="x">
                    <label>Y</label><input type="number" value="${Math.round(this.selectedObject.y)}" data-prop="y">
                </div>
                <div class="prop-row">
                    <label>W</label><input type="number" value="${Math.round(this.selectedObject.width)}" data-prop="width">
                    <label>H</label><input type="number" value="${Math.round(this.selectedObject.height)}" data-prop="height">
                </div>
            </div>
        `;

        // Custom properties if any
        if (this.selectedObject.customProps) {
            html += `<div class="props-section"><div class="props-section-title">CUSTOM</div>`;
            for (const [key, val] of Object.entries(this.selectedObject.customProps)) {
                html += `<div class="prop-row"><label>${key}</label><input type="text" value="${val}" data-prop="${key}"></div>`;
            }
            html += `</div>`;
        }

        container.innerHTML = html;

        // Bind events
        container.querySelectorAll('input').forEach(input => {
            input.onchange = (e) => {
                const prop = e.target.dataset.prop;
                const val = e.target.type === 'number' ? parseFloat(e.target.value) : e.target.value;
                this.updateProperty(prop, val);
            };
        });
    }

    updateProperty(prop, value) {
        if (!this.selectedObject) return;
        
        // This should be a command for undo/redo
        this.selectedObject[prop] = value;
        console.log(`Updated ${prop} to ${value}`);
        
        // Refresh game view if needed
        if (this.editor.adapter.onPropertyChange) {
            this.editor.adapter.onPropertyChange(this.selectedObject, prop, value);
        }
    }
}
