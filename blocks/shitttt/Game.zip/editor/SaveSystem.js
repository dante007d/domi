/* editor/SaveSystem.js */
export class SaveSystem {
    constructor(editor) {
        this.editor = editor;
    }

    serialize() {
        const state = window.gameState;
        const data = {
            version: "2.0",
            meta: {
                name: "New Level",
                worldWidth: 1280,
                worldHeight: 720,
                tileSize: 32,
                gravity: { x: 0, y: 0.6 }
            },
            platforms: state.platforms || [],
            hazards: state.hazards || [],
            entities: [
                { type: 'player', x: state.player.x, y: state.player.y }
            ]
        };
        return JSON.stringify(data, null, 2);
    }

    saveToFile() {
        const json = this.serialize();
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'level.json';
        a.click();
        URL.revokeObjectURL(url);
        
        this.editor.shell.showNotification("Level saved successfully!", "success");
    }

    async loadFromFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = JSON.parse(e.target.result);
                    this.applyData(data);
                    this.editor.shell.showNotification("Level loaded!", "success");
                    resolve(data);
                } catch (err) {
                    this.editor.shell.showNotification("Invalid level file", "error");
                    reject(err);
                }
            };
            reader.readAsText(file);
        });
    }

    applyData(data) {
        if (!window.gameState) return;
        window.gameState.platforms = data.platforms || [];
        window.gameState.hazards = data.hazards || [];
        if (data.entities) {
            const player = data.entities.find(e => e.type === 'player');
            if (player && window.gameState.player) {
                window.gameState.player.x = player.x;
                window.gameState.player.y = player.y;
            }
        }
    }
}
