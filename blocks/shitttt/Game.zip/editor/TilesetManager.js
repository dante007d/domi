/* editor/TilesetManager.js */
export class TilesetManager {
    constructor(editor) {
        this.editor = editor;
        this.tilesets = [];
        this.selectedTileId = null;
        this.tileSize = 32;
    }

    async addTileset(name, imageUrl) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                const tileset = {
                    id: 'ts_' + Date.now(),
                    name: name,
                    image: img,
                    width: img.width,
                    height: img.height,
                    cols: Math.floor(img.width / this.tileSize),
                    rows: Math.floor(img.height / this.tileSize)
                };
                this.tilesets.push(tileset);
                this.editor.shell.updateTilesUI(this.tilesets);
                resolve(tileset);
            };
            img.onerror = reject;
            img.src = imageUrl;
        });
    }

    selectTile(tilesetId, tileIndex) {
        this.selectedTileId = { tilesetId, tileIndex };
        this.editor.shell.updateSelectedTileUI(this.selectedTileId);
    }

    getTileData(tilesetId, tileIndex) {
        const ts = this.tilesets.find(t => t.id === tilesetId);
        if (!ts) return null;
        const x = (tileIndex % ts.cols) * this.tileSize;
        const y = Math.floor(tileIndex / ts.cols) * this.tileSize;
        return { image: ts.image, x, y, size: this.tileSize };
    }
}
