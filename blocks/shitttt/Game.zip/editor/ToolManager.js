/* editor/ToolManager.js */
import { SelectTool } from './tools/SelectTool.js';
import { DrawTool } from './tools/DrawTool.js';

export class ToolManager {
  constructor(editor) {
    this.editor = editor;
    this.tools = {
      select: new SelectTool(editor),
      draw: new DrawTool(editor)
    };
    this.activeTool = this.tools.select;
  }

  setTool(toolId) {
    if (this.tools[toolId]) {
      this.activeTool.deactivate();
      this.activeTool = this.tools[toolId];
      this.activeTool.activate();
    }
  }

  handleMouseDown(e) { this.activeTool.onMouseDown(e); }
  handleMouseMove(e) { this.activeTool.onMouseMove(e); }
  handleMouseUp(e) { this.activeTool.onMouseUp(e); }
}
