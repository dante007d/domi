/* editor/UIShell.js */
export class UIShell {
  constructor() {
    this.root = null;
    this.createDOM();
  }

  createDOM() {
    this.root = document.createElement('div');
    this.root.id = 'editor-root';
    this.root.innerHTML = `
      <div class="editor-shell">
        <div class="editor-toolbar">
          <div class="editor-logo">EDITOR</div>
          <div class="toolbar-group" id="file-menu">
            <button class="toolbar-btn" onclick="window._editor.saveSystem.saveToFile()">Save</button>
            <button class="toolbar-btn" onclick="document.getElementById('load-input').click()">Load</button>
            <input type="file" id="load-input" style="display:none" onchange="window._editor.saveSystem.loadFromFile(this.files[0])">
          </div>
          <div class="toolbar-group" id="tool-buttons">
            <button class="toolbar-btn active" data-tool="select">↖</button>
            <button class="toolbar-btn" data-tool="draw">✏</button>
            <button class="toolbar-btn" data-tool="erase">⬜</button>
            <button class="toolbar-btn" data-tool="entity">◈</button>
          </div>
          <div style="flex:1"></div>
          <button class="toolbar-btn" style="color:var(--editor-success)">▶ Test</button>
        </div>

        <div class="editor-left-panel">
          <div class="panel-tabs">
            <div class="tab-btn active">TOOLS</div>
            <div class="tab-btn">TILES</div>
            <div class="tab-btn">LAYERS</div>
          </div>
          <div class="panel-content">
            <div id="tools-content">
                <div id="tool-options">
                   <label>Grid Size</label>
                   <select><option>32</option><option>16</option></select>
                </div>
            </div>
            <div id="tiles-content" style="display:none;">
                <div class="tiles-grid"></div>
            </div>
            <div id="layers-content" style="display:none;">
                <div class="layers-list"></div>
            </div>
          </div>
        </div>

        <div class="editor-viewport">
          <canvas id="editor-canvas"></canvas>
          <div id="minimap" style="position:absolute; bottom:10px; right:10px; width:150px; height:100px; background:rgba(0,0,0,0.5); border:1px solid var(--editor-border);"></div>
          <div class="notification-container"></div>
        </div>

        <div class="editor-right-panel">
          <div class="panel-tabs">
            <div class="tab-btn active">PROPS</div>
            <div class="tab-btn">PHYSICS</div>
          </div>
          <div class="panel-content" id="properties-inspector">
            <div style="color:var(--editor-text-dim); font-size:11px;">Select an object to edit properties</div>
          </div>
        </div>

        <div class="editor-status-bar">
          <span id="coord-display">X: 0 Y: 0</span>
          <span id="undo-status" style="margin-left:20px; color:var(--editor-accent);"></span>
          <span style="margin-left:auto">Level: level1.json</span>
        </div>
      </div>
    `;

    // Tab switching logic
    this.root.querySelectorAll('.editor-left-panel .tab-btn').forEach((btn, idx) => {
        btn.onclick = () => {
            this.root.querySelectorAll('.editor-left-panel .tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            this.root.querySelector('#tools-content').style.display = idx === 0 ? 'block' : 'none';
            this.root.querySelector('#tiles-content').style.display = idx === 1 ? 'block' : 'none';
            this.root.querySelector('#layers-content').style.display = idx === 2 ? 'block' : 'none';
        };
    });

    // Handle tool switching
    this.root.querySelectorAll('[data-tool]').forEach(btn => {
      btn.onclick = () => {
        window._editor.setTool(btn.dataset.tool);
      };
    });
  }

  mount(parent) {
    parent.appendChild(this.root);
  }

  show() {
    this.root.classList.add('active');
  }

  hide() {
    this.root.classList.remove('active');
  }

  updateToolUI(activeTool) {
    this.root.querySelectorAll('[data-tool]').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tool === activeTool);
    });
  }

  updateLayersUI(layers, activeIndex) {
      const list = this.root.querySelector('.layers-list');
      if (!list) return;
      list.innerHTML = layers.map((layer, i) => `
          <div class="layer-item ${i === activeIndex ? 'active' : ''}" onclick="window._editor.layers.setActiveLayer(${i})">
              <span>${layer.visible ? '👁' : '🕶'}</span>
              <span>${layer.name}</span>
          </div>
      `).join('');
  }

  updateUndoUI(lastCommand) {
      const status = this.root.querySelector('#undo-status');
      if (status) status.innerText = `Last: ${lastCommand}`;
  }

  showNotification(text, type = 'info') {
      const container = this.root.querySelector('.notification-container');
      const el = document.createElement('div');
      el.className = `notification ${type}`;
      el.innerText = text;
      container.appendChild(el);
      setTimeout(() => el.remove(), 3000);
  }

  updateTilesUI(tilesets) {
      const grid = this.root.querySelector('.tiles-grid');
      if (!grid) return;
      grid.innerHTML = tilesets.map(ts => {
          let tilesHtml = '';
          for (let i = 0; i < ts.cols * ts.rows; i++) {
              tilesHtml += `<div class="tile-item" data-ts="${ts.id}" data-idx="${i}" onclick="window._editor.tiles.selectTile('${ts.id}', ${i})"></div>`;
          }
          return tilesHtml;
      }).join('');
  }

  updateSelectedTileUI(selectedId) {
      this.root.querySelectorAll('.tile-item').forEach(el => {
          const isActive = el.dataset.ts === selectedId.tilesetId && parseInt(el.dataset.idx) === selectedId.tileIndex;
          el.classList.toggle('active', isActive);
      });
  }
}


