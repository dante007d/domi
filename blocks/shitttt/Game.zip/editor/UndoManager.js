/* editor/UndoManager.js */
export class UndoManager {
    constructor(editor) {
        this.editor = editor;
        this.undoStack = [];
        this.redoStack = [];
        this.maxHistory = 200;
    }

    execute(command) {
        command.execute();
        this.undoStack.push(command);
        this.redoStack = []; // Clear redo on new action
        
        if (this.undoStack.length > this.maxHistory) {
            this.undoStack.shift();
        }

        console.log(`Command Executed: ${command.name}`);
        this.editor.shell.updateUndoUI(command.name);
    }

    undo() {
        if (this.undoStack.length === 0) return;
        const command = this.undoStack.pop();
        command.undo();
        this.redoStack.push(command);
        console.log(`Undone: ${command.name}`);
    }

    redo() {
        if (this.redoStack.length === 0) return;
        const command = this.redoStack.pop();
        command.execute();
        this.undoStack.push(command);
        console.log(`Redone: ${command.name}`);
    }
}

// Example Command Interface
/*
class PaintTileCommand {
    constructor(editor, x, y, tileId) {
        this.name = "Paint Tile";
        this.editor = editor;
        this.x = x; this.y = y; this.tileId = tileId;
        this.oldTileId = null;
    }
    execute() {
        this.oldTileId = this.editor.adapter.getTileAt(this.x, this.y);
        this.editor.adapter.setTileAt(this.x, this.y, this.tileId);
    }
    undo() {
        this.editor.adapter.setTileAt(this.x, this.y, this.oldTileId);
    }
}
*/
