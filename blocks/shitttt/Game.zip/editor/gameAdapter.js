/* editor/gameAdapter.js */
export const gameAdapter = {
  game: null,
  canvas: null,
  ctx: null,

  init(game) {
    this.game = game; // In this case, window.gameState or similar
    this.canvas = document.getElementById('gameCanvas');
    this.ctx = this.canvas.getContext('2d');
  },

  pause() {
    if (this.game) this.game.isRunning = false;
  },

  resume() {
    if (this.game) this.game.isRunning = true;
  },

  getWorldDimensions() {
    return { width: 1280, height: 720 };
  },

  getTileAt(x, y, layer) {
    // Basic implementation for our simple game
    const platforms = window.gameState.platforms || [];
    return platforms.find(p => 
      x >= p.x && x < p.x + p.width && 
      y >= p.y && y < p.y + p.height
    );
  },

  setTileAt(x, y, layer, tileId) {
    // This would modify the level data
  },

  spawnEntity(config) {
    // Spawn enemy or hazard
  },

  getAllEntities() {
    return {
      player: window.gameState.player,
      enemies: window.gameState.enemies || [],
      hazards: window.gameState.hazards || []
    };
  }
};
