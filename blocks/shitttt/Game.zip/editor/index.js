/* editor/index.js */
import { EditorCore } from './EditorCore.js';
import { UIShell } from './UIShell.js';
import { gameAdapter } from './gameAdapter.js';

let editorInstance = null;

export function initEditor(game) {
  if (editorInstance) return editorInstance;

  // Set up the adapter
  gameAdapter.init(game);

  // Initialize UI Shell
  const shell = new UIShell();
  shell.mount(document.body);

  // Initialize Core
  editorInstance = new EditorCore(shell, gameAdapter);
  
  // Expose for debugging
  window._editor = editorInstance;

  console.log("Level Editor v2 Initialized. Press ` to toggle.");
  return editorInstance;
}
