/* editor/tools/DrawTool.js */
export class DrawTool {
  constructor(editor) {
    this.editor = editor;
    this.isDrawing = false;
  }

  activate() { console.log("Draw Tool Active"); }
  deactivate() {}

  onMouseDown(e) {
    this.isDrawing = true;
    this.paint(e);
  }

  onMouseMove(e) {
    if (this.isDrawing) this.paint(e);
  }

  onMouseUp(e) {
    this.isDrawing = false;
  }

  paint(e) {
    const canvas = document.getElementById('editor-canvas');
    const worldPos = this.editor.camera.screenToWorld(e.clientX, e.clientY, canvas);
    // Snap to grid
    const gs = 32;

    const gx = Math.floor(worldPos.x / gs) * gs;
    const gy = Math.floor(worldPos.y / gs) * gs;
    
    // Actually add a platform
    if (window.gameState) {
        // Avoid duplicates at same spot
        const exists = window.gameState.platforms.some(p => p.x === gx && p.y === gy && p.width === gs);
        if (!exists) {
            window.gameState.platforms.push({ x: gx, y: gy, width: gs, height: gs, type: 'platform' });
            console.log("Added platform at", gx, gy);
        }
    }
  }
}
