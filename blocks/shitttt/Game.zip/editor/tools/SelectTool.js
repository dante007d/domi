/* editor/tools/SelectTool.js */
export class SelectTool {
  constructor(editor) {
    this.editor = editor;
  }

  activate() { console.log("Select Tool Active"); }
  deactivate() {}

  onMouseDown(e) {
    const canvas = document.getElementById('editor-canvas');
    const worldPos = this.editor.camera.screenToWorld(e.clientX, e.clientY, canvas);
    console.log("Selecting at:", worldPos);
    
    // Find object under cursor
    const obj = this.editor.adapter.getTileAt(worldPos.x, worldPos.y);
    if (obj) {
        this.editor.props.inspect(obj);
    } else {
        this.editor.props.inspect(null);
    }
  }


  onMouseMove(e) {}
  onMouseUp(e) {}
}
