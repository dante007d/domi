/**
 * Katana Inspired Platformer Game Logic
 */

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Game Constants
const CANVAS_WIDTH = 1280;
const CANVAS_HEIGHT = 720;
const GRAVITY = 0.6;
const JUMP_STRENGTH = -13;
const PLAYER_SIZE = 30;
const DASH_SPEED = 20;
const DASH_COOLDOWN_FRAMES = 60;
const MOVE_SPEED = 6;

// Sprite Colors
const SPRITE_COLORS = {
    player: '#00e5ff',
    playerDash: '#ff4081',
    platform: '#8b4513',
    enemy: '#ff1744',
    hazard_spike: '#ff6f00',
    hazard_lava: '#ff3d00',
    hazard_laser: '#e040fb',
    goal: '#76ff03',
    background: '#0a0a1a',
    text: '#ffffff',
    hud: '#00e5ff'
};

// Set up canvas dimensions
canvas.width = CANVAS_WIDTH;
canvas.height = CANVAS_HEIGHT;

// Game state management
window.gameState = {
    currentLevel: 1,
    isRunning: false,
    showStartScreen: true,
    player: null,
    platforms: [],
    hazards: [],
    enemies: [],
    particles: [],
    score: 0,
    goal: null,
    keys: {
        left: false,
        right: false,
        jump: false,
        dash: false
    }
};

// ── Helper Drawing Functions ──

function drawRect(x, y, w, h, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
}

function drawText(text, x, y, size, color, align) {
    ctx.fillStyle = color || SPRITE_COLORS.text;
    ctx.font = `bold ${size}px 'Segoe UI', sans-serif`;
    ctx.textAlign = align || 'left';
    ctx.fillText(text, x, y);
}

// ── Player Class ──

class Player {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = PLAYER_SIZE;
        this.height = PLAYER_SIZE;
        this.vx = 0;
        this.vy = 0;
        this.isGrounded = false;
        this.isJumping = false;
        this.maxHealth = 3;
        this.health = 3;
        this.dashCooldown = 0;
        this.isDashing = false;
        this.dashTimer = 0;
        this.facingRight = true;
        this.trailHistory = [];
    }

    update() {
        // Trail effect
        if (this.isDashing) {
            this.trailHistory.push({ x: this.x, y: this.y, alpha: 0.6 });
        }
        if (this.trailHistory.length > 8) this.trailHistory.shift();
        this.trailHistory = this.trailHistory.map(t => ({ ...t, alpha: t.alpha - 0.08 })).filter(t => t.alpha > 0);

        // Dash logic
        if (this.isDashing) {
            this.dashTimer--;
            if (this.dashTimer <= 0) {
                this.isDashing = false;
                this.vx = 0;
            }
        }

        // Apply gravity (reduced during dash)
        if (!this.isDashing) {
            this.vy += GRAVITY;
        }

        // Horizontal movement (only when not dashing)
        if (!this.isDashing) {
            this.vx = 0;
            if (window.gameState.keys.left) {
                this.vx = -MOVE_SPEED;
                this.facingRight = false;
            } else if (window.gameState.keys.right) {
                this.vx = MOVE_SPEED;
                this.facingRight = true;
            }
        }

        // Jumping
        if (window.gameState.keys.jump && this.isGrounded && !this.isJumping) {
            this.vy = JUMP_STRENGTH;
            this.isJumping = true;
            this.isGrounded = false;
            spawnParticles(this.x + this.width / 2, this.y + this.height, 5, '#00e5ff');
        }

        // Release jump key to allow re-jump
        if (!window.gameState.keys.jump) {
            this.isJumping = false;
        }

        // Dash
        if (window.gameState.keys.dash && this.dashCooldown <= 0 && !this.isDashing) {
            this.dash();
        }

        if (this.dashCooldown > 0) this.dashCooldown--;

        // Update position
        this.x += this.vx;
        this.y += this.vy;

        // Platform collision
        this.isGrounded = false;
        for (const platform of window.gameState.platforms) {
            if (this.x + this.width > platform.x &&
                this.x < platform.x + platform.width &&
                this.y + this.height > platform.y &&
                this.y + this.height < platform.y + platform.height + this.vy + 2 &&
                this.vy >= 0) {
                // Landing on top
                this.y = platform.y - this.height;
                this.vy = 0;
                this.isGrounded = true;
            }
            // Head bump (hitting from below)
            if (this.x + this.width > platform.x &&
                this.x < platform.x + platform.width &&
                this.y < platform.y + platform.height &&
                this.y > platform.y &&
                this.vy < 0) {
                this.y = platform.y + platform.height;
                this.vy = 0;
            }
            // Side collision
            if (this.y + this.height > platform.y + 4 &&
                this.y < platform.y + platform.height - 4) {
                if (this.x + this.width > platform.x && this.x + this.width < platform.x + 10 && this.vx > 0) {
                    this.x = platform.x - this.width;
                    this.vx = 0;
                }
                if (this.x < platform.x + platform.width && this.x > platform.x + platform.width - 10 && this.vx < 0) {
                    this.x = platform.x + platform.width;
                    this.vx = 0;
                }
            }
        }

        // Hazard collision
        for (const hazard of window.gameState.hazards) {
            if (this.x + this.width > hazard.x &&
                this.x < hazard.x + hazard.width &&
                this.y + this.height > hazard.y &&
                this.y < hazard.y + hazard.height) {
                this.takeDamage();
            }
        }

        // Goal check
        if (window.gameState.goal) {
            const g = window.gameState.goal;
            if (this.x + this.width > g.x &&
                this.x < g.x + g.width &&
                this.y + this.height > g.y &&
                this.y < g.y + g.height) {
                nextLevel();
            }
        }

        // Boundary checking
        if (this.x < 0) { this.x = 0; this.vx = 0; }
        if (this.x + this.width > CANVAS_WIDTH) { this.x = CANVAS_WIDTH - this.width; this.vx = 0; }

        // Fall off screen → respawn
        if (this.y > CANVAS_HEIGHT + 50) {
            this.takeDamage();
        }
    }

    dash() {
        const dir = this.facingRight ? 1 : -1;
        this.vx = dir * DASH_SPEED;
        this.vy = 0;
        this.isDashing = true;
        this.dashTimer = 8;
        this.dashCooldown = DASH_COOLDOWN_FRAMES;
        spawnParticles(this.x + this.width / 2, this.y + this.height / 2, 8, '#ff4081');
    }

    takeDamage() {
        this.health--;
        spawnParticles(this.x + this.width / 2, this.y + this.height / 2, 12, '#ff1744');
        if (this.health <= 0) {
            gameOver();
        } else {
            // Respawn at level start
            this.x = 100;
            this.y = CANVAS_HEIGHT - 150;
            this.vx = 0;
            this.vy = 0;
        }
    }

    draw() {
        // Draw trail
        for (const t of this.trailHistory) {
            ctx.globalAlpha = t.alpha;
            drawRect(t.x, t.y, this.width, this.height, SPRITE_COLORS.playerDash);
            ctx.globalAlpha = 1;
        }

        // Draw player
        const color = this.isDashing ? SPRITE_COLORS.playerDash : SPRITE_COLORS.player;
        drawRect(this.x, this.y, this.width, this.height, color);

        // Eye
        ctx.fillStyle = '#000';
        const eyeX = this.facingRight ? this.x + 20 : this.x + 6;
        ctx.fillRect(eyeX, this.y + 8, 5, 5);

        // Glow effect
        ctx.shadowColor = color;
        ctx.shadowBlur = 15;
        drawRect(this.x + 2, this.y + 2, this.width - 4, this.height - 4, color);
        ctx.shadowBlur = 0;
    }
}

// ── Particle System ──

function spawnParticles(x, y, count, color) {
    for (let i = 0; i < count; i++) {
        window.gameState.particles.push({
            x: x,
            y: y,
            vx: (Math.random() - 0.5) * 6,
            vy: (Math.random() - 0.5) * 6,
            life: 20 + Math.random() * 15,
            color: color,
            size: 2 + Math.random() * 4
        });
    }
}

function updateParticles() {
    for (let i = window.gameState.particles.length - 1; i >= 0; i--) {
        const p = window.gameState.particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life--;
        p.size *= 0.96;
        if (p.life <= 0) {
            window.gameState.particles.splice(i, 1);
        }
    }
}

function drawParticles() {
    for (const p of window.gameState.particles) {
        ctx.globalAlpha = p.life / 35;
        drawRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size, p.color);
    }
    ctx.globalAlpha = 1;
}

// ── Level Definitions ──

function loadLevel(levelNum) {
    window.gameState.platforms = [];
    window.gameState.hazards = [];
    window.gameState.enemies = [];
    window.gameState.particles = [];

    const floorY = CANVAS_HEIGHT - 40;

    if (levelNum === 1) {
        // Floor
        window.gameState.platforms.push({ x: 0, y: floorY, width: 500, height: 40 });
        window.gameState.platforms.push({ x: 600, y: floorY, width: 680, height: 40 });

        // Platforms
        window.gameState.platforms.push({ x: 200, y: 520, width: 150, height: 20 });
        window.gameState.platforms.push({ x: 450, y: 440, width: 150, height: 20 });
        window.gameState.platforms.push({ x: 700, y: 380, width: 150, height: 20 });
        window.gameState.platforms.push({ x: 950, y: 320, width: 200, height: 20 });

        // Hazards (spikes in the gap)
        window.gameState.hazards.push({ x: 510, y: floorY - 15, width: 80, height: 15, type: 'spike' });

        // Goal
        window.gameState.goal = { x: 1100, y: 280, width: 30, height: 40 };

    } else if (levelNum === 2) {
        // More challenging layout
        window.gameState.platforms.push({ x: 0, y: floorY, width: 300, height: 40 });
        window.gameState.platforms.push({ x: 400, y: 580, width: 120, height: 20 });
        window.gameState.platforms.push({ x: 600, y: 500, width: 120, height: 20 });
        window.gameState.platforms.push({ x: 350, y: 420, width: 120, height: 20 });
        window.gameState.platforms.push({ x: 550, y: 340, width: 120, height: 20 });
        window.gameState.platforms.push({ x: 780, y: 400, width: 150, height: 20 });
        window.gameState.platforms.push({ x: 1000, y: 320, width: 280, height: 20 });
        window.gameState.platforms.push({ x: 950, y: floorY, width: 330, height: 40 });

        // Hazards
        window.gameState.hazards.push({ x: 310, y: floorY - 15, width: 80, height: 15, type: 'spike' });
        window.gameState.hazards.push({ x: 730, y: 380, width: 40, height: 20, type: 'lava' });

        // Goal
        window.gameState.goal = { x: 1200, y: 280, width: 30, height: 40 };

    } else if (levelNum === 3) {
        // Vertical challenge
        window.gameState.platforms.push({ x: 0, y: floorY, width: 200, height: 40 });
        window.gameState.platforms.push({ x: 100, y: 560, width: 100, height: 20 });
        window.gameState.platforms.push({ x: 250, y: 480, width: 100, height: 20 });
        window.gameState.platforms.push({ x: 50, y: 400, width: 100, height: 20 });
        window.gameState.platforms.push({ x: 250, y: 320, width: 100, height: 20 });
        window.gameState.platforms.push({ x: 450, y: 260, width: 100, height: 20 });
        window.gameState.platforms.push({ x: 650, y: 320, width: 100, height: 20 });
        window.gameState.platforms.push({ x: 850, y: 260, width: 100, height: 20 });
        window.gameState.platforms.push({ x: 1050, y: 200, width: 200, height: 20 });

        // Hazards everywhere
        window.gameState.hazards.push({ x: 150, y: 460, width: 80, height: 15, type: 'spike' });
        window.gameState.hazards.push({ x: 350, y: 300, width: 80, height: 15, type: 'lava' });
        window.gameState.hazards.push({ x: 750, y: 300, width: 80, height: 15, type: 'laser' });

        // Goal
        window.gameState.goal = { x: 1180, y: 160, width: 30, height: 40 };
    } else {
        // You win — show message
        window.gameState.isRunning = false;
        window.gameState.showStartScreen = true;
        window.gameState.currentLevel = 1;
        drawWinScreen();
        return;
    }

    // Reset player position
    window.gameState.player.x = 100;
    window.gameState.player.y = floorY - PLAYER_SIZE - 20;
    window.gameState.player.vx = 0;
    window.gameState.player.vy = 0;
    window.gameState.player.isGrounded = false;
}

// ── Drawing Functions ──

function drawBackground() {
    // Dark gradient background
    const grad = ctx.createLinearGradient(0, 0, 0, CANVAS_HEIGHT);
    grad.addColorStop(0, '#0a0a2e');
    grad.addColorStop(1, '#0a0a1a');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Starfield
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    for (let i = 0; i < 80; i++) {
        const sx = (i * 173 + 37) % CANVAS_WIDTH;
        const sy = (i * 89 + 51) % CANVAS_HEIGHT;
        const ss = ((i * 7) % 3) + 1;
        ctx.fillRect(sx, sy, ss, ss);
    }
}

function drawPlatforms() {
    for (const platform of window.gameState.platforms) {
        // Platform body
        const grad = ctx.createLinearGradient(platform.x, platform.y, platform.x, platform.y + platform.height);
        grad.addColorStop(0, '#a0522d');
        grad.addColorStop(1, '#5c3317');
        ctx.fillStyle = grad;
        ctx.fillRect(platform.x, platform.y, platform.width, platform.height);

        // Top highlight
        ctx.fillStyle = 'rgba(255,255,255,0.15)';
        ctx.fillRect(platform.x, platform.y, platform.width, 3);
    }
}

function drawHazards() {
    for (const hazard of window.gameState.hazards) {
        let color;
        switch (hazard.type) {
            case 'spike': color = SPRITE_COLORS.hazard_spike; break;
            case 'lava': color = SPRITE_COLORS.hazard_lava; break;
            case 'laser': color = SPRITE_COLORS.hazard_laser; break;
            default: color = '#f00';
        }
        // Pulsing glow
        const pulse = 0.6 + Math.sin(Date.now() / 200) * 0.4;
        ctx.globalAlpha = pulse;
        ctx.shadowColor = color;
        ctx.shadowBlur = 12;
        drawRect(hazard.x, hazard.y, hazard.width, hazard.height, color);
        ctx.shadowBlur = 0;
        ctx.globalAlpha = 1;
    }
}

function drawGoal() {
    if (!window.gameState.goal) return;
    const g = window.gameState.goal;
    const pulse = 0.7 + Math.sin(Date.now() / 300) * 0.3;
    ctx.globalAlpha = pulse;
    ctx.shadowColor = SPRITE_COLORS.goal;
    ctx.shadowBlur = 20;
    drawRect(g.x, g.y, g.width, g.height, SPRITE_COLORS.goal);
    ctx.shadowBlur = 0;
    ctx.globalAlpha = 1;

    // Arrow above goal
    ctx.fillStyle = SPRITE_COLORS.goal;
    const arrowY = g.y - 20 + Math.sin(Date.now() / 400) * 5;
    ctx.beginPath();
    ctx.moveTo(g.x + g.width / 2, arrowY);
    ctx.lineTo(g.x + g.width / 2 - 8, arrowY - 12);
    ctx.lineTo(g.x + g.width / 2 + 8, arrowY - 12);
    ctx.closePath();
    ctx.fill();
}

function drawHUD() {
    // Health
    for (let i = 0; i < window.gameState.player.maxHealth; i++) {
        const color = i < window.gameState.player.health ? '#ff1744' : '#333';
        drawRect(20 + i * 35, 20, 25, 25, color);
        // Heart shape outline
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 1;
        ctx.strokeRect(20 + i * 35, 20, 25, 25);
    }

    // Score
    drawText(`SCORE: ${window.gameState.score}`, CANVAS_WIDTH - 20, 42, 20, SPRITE_COLORS.hud, 'right');

    // Level
    drawText(`LEVEL ${window.gameState.currentLevel}`, CANVAS_WIDTH / 2, 42, 22, SPRITE_COLORS.hud, 'center');

    // Dash cooldown indicator
    if (window.gameState.player.dashCooldown > 0) {
        const pct = window.gameState.player.dashCooldown / DASH_COOLDOWN_FRAMES;
        ctx.fillStyle = 'rgba(255,64,129,0.3)';
        ctx.fillRect(20, 55, 100, 8);
        ctx.fillStyle = '#ff4081';
        ctx.fillRect(20, 55, 100 * (1 - pct), 8);
    } else {
        ctx.fillStyle = '#ff4081';
        ctx.fillRect(20, 55, 100, 8);
        drawText('DASH READY', 25, 80, 10, '#ff4081');
    }
}

// ── Screens ──

function drawStartScreen() {
    // Background
    const grad = ctx.createLinearGradient(0, 0, 0, CANVAS_HEIGHT);
    grad.addColorStop(0, '#0a0a2e');
    grad.addColorStop(0.5, '#1a0030');
    grad.addColorStop(1, '#0a0a1a');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Title glow
    ctx.shadowColor = '#00e5ff';
    ctx.shadowBlur = 30;
    drawText('KATANA', CANVAS_WIDTH / 2, 280, 80, '#00e5ff', 'center');
    ctx.shadowBlur = 0;
    drawText('PLATFORMER', CANVAS_WIDTH / 2, 340, 36, '#ff4081', 'center');

    // Instructions
    const blink = Math.sin(Date.now() / 500) > 0;
    if (blink) {
        drawText('PRESS ENTER TO START', CANVAS_WIDTH / 2, 440, 22, '#fff', 'center');
    }

    drawText('WASD / ARROWS — Move & Jump', CANVAS_WIDTH / 2, 510, 16, '#888', 'center');
    drawText('SHIFT — Dash', CANVAS_WIDTH / 2, 540, 16, '#888', 'center');
    drawText('Reach the green goal to advance!', CANVAS_WIDTH / 2, 580, 14, '#666', 'center');
}

function drawGameOverScreen() {
    ctx.fillStyle = 'rgba(0,0,0,0.7)';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    ctx.shadowColor = '#ff1744';
    ctx.shadowBlur = 25;
    drawText('GAME OVER', CANVAS_WIDTH / 2, 320, 64, '#ff1744', 'center');
    ctx.shadowBlur = 0;

    drawText(`SCORE: ${window.gameState.score}`, CANVAS_WIDTH / 2, 390, 28, '#fff', 'center');

    const blink = Math.sin(Date.now() / 500) > 0;
    if (blink) {
        drawText('PRESS ENTER TO RESTART', CANVAS_WIDTH / 2, 460, 22, '#fff', 'center');
    }
}

function drawWinScreen() {
    const grad = ctx.createLinearGradient(0, 0, 0, CANVAS_HEIGHT);
    grad.addColorStop(0, '#002200');
    grad.addColorStop(1, '#0a0a1a');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    ctx.shadowColor = '#76ff03';
    ctx.shadowBlur = 30;
    drawText('YOU WIN!', CANVAS_WIDTH / 2, 300, 72, '#76ff03', 'center');
    ctx.shadowBlur = 0;

    drawText(`FINAL SCORE: ${window.gameState.score}`, CANVAS_WIDTH / 2, 380, 32, '#fff', 'center');

    const blink = Math.sin(Date.now() / 500) > 0;
    if (blink) {
        drawText('PRESS ENTER TO PLAY AGAIN', CANVAS_WIDTH / 2, 460, 22, '#fff', 'center');
    }
}

// ── Game State Transitions ──

function startGame() {
    window.gameState.isRunning = true;
    window.gameState.showStartScreen = false;
    window.gameState.score = 0;
    window.gameState.currentLevel = 1;
    window.gameState.player = new Player(100, CANVAS_HEIGHT - 150);
    window.gameState.player.health = window.gameState.player.maxHealth;
    loadLevel(1);
}

function nextLevel() {
    window.gameState.score += 500;
    window.gameState.currentLevel++;
    spawnParticles(window.gameState.player.x, window.gameState.player.y, 20, '#76ff03');
    loadLevel(window.gameState.currentLevel);
}

function gameOver() {
    window.gameState.isRunning = false;
    window.gameState.showStartScreen = false;
}

// ── Input Handling ──

document.addEventListener('keydown', (e) => {
    // Start / Restart
    if (e.key === 'Enter') {
        if (window.gameState.showStartScreen || !window.gameState.isRunning) {
            startGame();
            return;
        }
    }

    if (!window.gameState.isRunning) return;

    switch (e.key) {
        case 'ArrowLeft':
        case 'a':
            window.gameState.keys.left = true;
            break;
        case 'ArrowRight':
        case 'd':
            window.gameState.keys.right = true;
            break;
        case ' ':
        case 'w':
        case 'ArrowUp':
            window.gameState.keys.jump = true;
            e.preventDefault();
            break;
        case 'Shift':
            window.gameState.keys.dash = true;
            break;
    }
});

document.addEventListener('keyup', (e) => {
    switch (e.key) {
        case 'ArrowLeft':
        case 'a':
            window.gameState.keys.left = false;
            break;
        case 'ArrowRight':
        case 'd':
            window.gameState.keys.right = false;
            break;
        case ' ':
        case 'w':
        case 'ArrowUp':
            window.gameState.keys.jump = false;
            break;
        case 'Shift':
            window.gameState.keys.dash = false;
            break;
    }
});

// ── Main Game Loop ──

function gameLoop() {
    // If editor is active, we skip the start screen to allow editing
    const isEditorActive = window._editor && window._editor.active;

    if (window.gameState.showStartScreen && !isEditorActive) {
        drawStartScreen();
        requestAnimationFrame(gameLoop);
        return;
    }

    if (!window.gameState.isRunning && !isEditorActive) {
        drawGameOverScreen();
        requestAnimationFrame(gameLoop);
        return;
    }

    // Update (only if running)
    if (window.gameState.isRunning) {
        window.gameState.player.update();
        updateParticles();
    }

    // Draw (always draw if running or editor is active)
    drawBackground();
    drawPlatforms();
    drawHazards();
    drawGoal();
    window.gameState.player.draw();
    drawParticles();
    drawHUD();

    requestAnimationFrame(gameLoop);
}

// ── Initialize ──
window.gameState.player = new Player(100, CANVAS_HEIGHT - 150);
requestAnimationFrame(gameLoop);
